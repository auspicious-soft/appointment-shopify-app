@extends('shopify-app::layouts.default')

@section('content')
    <!-- You are: (shop domain name) -->
    <p>This app is using to book the appointment and assign the assistant to customer.</p>
    
    
@endsection

@section('scripts')
    @parent
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

    <script>
        actions.TitleBar.create(app, { title: 'Welcome' });
    </script>
    
@endsection