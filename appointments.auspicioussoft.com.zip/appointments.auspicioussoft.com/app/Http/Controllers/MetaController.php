<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST');
header("Access-Control-Allow-Headers: X-Requested-With");
class MetaController extends Controller

{
    public function index(Request $request)
    {
        
        $customer_id = $request->input('user_id');
        $value = $request->input('value');
        
        $metafieldupdatevalueone = array(
            
            "metafield" => array(
                "namespace"=>"custom",
                "key"=>"assistant",
                "value"=>$value,
                "type"=>"single_line_text_field"
            ),
            
        );
                  
      $post_meta  =  json_encode($metafieldupdatevalueone);      
            
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://87f5b73d7185689e84624cef753b36f3:shpua_a8294010a97b5cb208ad05ca2b394e57@appointment-booking-app.myshopify.com/admin/api/2022-10/customers/'.$customer_id.'/metafields.json',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
             CURLOPT_POSTFIELDS =>$post_meta,
            CURLOPT_HTTPHEADER => array(
            'Content-Type: application/json'
            )
        ));
        
        $response = curl_exec($curl);
        
        curl_close($curl);
        
        return response()->json([ 'success' => true]);
    }
}
