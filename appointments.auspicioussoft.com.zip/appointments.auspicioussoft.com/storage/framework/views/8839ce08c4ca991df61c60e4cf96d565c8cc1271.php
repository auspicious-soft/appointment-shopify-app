

<?php $__env->startSection('content'); ?>
    <!-- You are: (shop domain name) -->
    <p>This app is using to book the appointment and assign the assistant to customer.</p>
    
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

    <script>
        actions.TitleBar.create(app, { title: 'Welcome' });
    </script>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('shopify-app::layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/digidcor/public_html/appointments.auspicioussoft.com/resources/views/welcome.blade.php ENDPATH**/ ?>